import React, { VoidFunctionComponent } from "react";

export interface Pesanan {
    id: string,
    documentId:string,
    nama: string,
    foto: string,
    fotoURL: string,
    harga: number,
    jumlah: number,
    pesan: string
}

const PesananContext = React.createContext<{
    pesanan: Pesanan[];
    addKeranjang: (documentId: string, nama: string, foto: string, fotoURL: string, harga: number, jumlah: number, pesan: string) => void;
    deleteKeranjang: () => void,
    deleteSatuan: (id: string) => void,
    initContext: () => void;
}>({
    pesanan: [],
    addKeranjang: () => { },
    deleteKeranjang: () => { },
    deleteSatuan: () =>{},
    initContext: () => { }
});

export default PesananContext;