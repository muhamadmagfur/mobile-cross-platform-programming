import { IonPage, IonHeader, IonToolbar, IonButtons, IonBackButton, IonTitle, IonContent, IonList, IonCard, IonLabel } from "@ionic/react";
import React from "react";
import firebaseConfig from '../../firebaseConfig'
import { getFirestore, getDocs, collection, doc } from 'firebase/firestore';
import { useState, useEffect } from "react";
import { useParams } from "react-router";

const Daftar: React.FC = () => {
    const db = getFirestore(firebaseConfig);
    const [daftarMakananUtama, setDaftarMakananUtama] = useState<Array<any>>([]);
    const [daftarMakananRingan, setDaftarMakananRingan] = useState<Array<any>>([]);
    const [daftarMinuman, setDaftarMinuman] = useState<Array<any>>([]);

    const jenis = useParams<{ jenis: string }>().jenis;

    useEffect(() => {
        async function getData() {
            const querysnapshotUtama = await getDocs(collection(db, "daftar-makanan"));
            const querySnapshotRingan = await getDocs(collection(db, "daftar-makanan-ringan"));
            const querySnapshotminuman = await getDocs(collection(db, "daftar-minuman"));
            console.log('QuerySnaphoot ', querysnapshotUtama);
            setDaftarMakananUtama(querysnapshotUtama.docs.map((doc) => ({ ...doc.data(), id: doc.id })));
            setDaftarMakananRingan(querySnapshotRingan.docs.map((doc) => ({ ...doc.data(), id: doc.id })));
            setDaftarMinuman(querySnapshotminuman.docs.map((doc) => ({ ...doc.data(), id: doc.id })));
            querysnapshotUtama.forEach((doc) => {
                console.log(`${doc.id}=>${doc.data()}`);
                console.log('docs:', doc);
            });
        }
        getData();

    }, []);
    return (
        <IonPage>
            <IonHeader>
                <IonToolbar color="danger">
                    <IonButtons>
                        <IonBackButton className="Title" defaultHref={jenis === 'utama' || 'ringan' ? "/pilihjenismakanan" : '/home'} ></IonBackButton>
                        <IonTitle className="Title">{jenis === 'utama' ? 'Daftar Makanan Utama' : jenis === 'ringan' ? 'Daftar Makanan Ringan' : "Daftar Minuman"}</IonTitle>
                    </IonButtons>
                </IonToolbar>
            </IonHeader>
            <IonContent>
                {jenis == 'utama' ? daftarMakananUtama.map(makanan => (
                    <IonCard button href={`/preview/${makanan.id}/${jenis}/${makanan.nama}/${makanan.harga}/${makanan.deskripsi}/${makanan.foto}/${makanan.fotoURL}`} className="pilih-makanan">
                        <img className="absolute" width="100%" src={`https://firebasestorage.googleapis.com/v0/b/uas-umn.appspot.com/o/${makanan.foto}?${makanan.fotoURL}`} alt={makanan.title} />
                        <IonLabel color="light" className="absolute top-card sub-header ml-10px">{makanan.nama}</IonLabel>
                    </IonCard>
                )) : jenis == 'ringan' ? daftarMakananRingan.map(makanan => (
                    <IonCard button href={`/preview/${makanan.id}/${jenis}/${makanan.nama}/${makanan.harga}/${makanan.deskripsi}/${makanan.foto}/${makanan.fotoURL}`} className="pilih-makanan">
                        <img className="absolute" width="100%" src={`https://firebasestorage.googleapis.com/v0/b/uas-umn.appspot.com/o/${makanan.foto}?${makanan.fotoURL}`} alt={makanan.title} />
                        <IonLabel color="light" className="absolute top-card sub-header ml-10px">{makanan.nama}</IonLabel>
                    </IonCard>
                )) : daftarMinuman.map(minuman => (
                    <IonCard button href={`/preview/${minuman.id}/${jenis}/${minuman.nama}/${minuman.harga}/${minuman.deskripsi}/${minuman.foto}/${minuman.fotoURL}`} className="pilih-makanan">
                        <img className="absolute" width="100%" src={`https://firebasestorage.googleapis.com/v0/b/uas-umn.appspot.com/o/${minuman.foto}?${minuman.fotoURL}`} alt={minuman.title} />
                        <IonLabel color="light" className="absolute top-card sub-header ml-10px">{minuman.nama}</IonLabel>
                    </IonCard>
                ))
                }
            </IonContent>
        </IonPage>
    )
}

export default Daftar;