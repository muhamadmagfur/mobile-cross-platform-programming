import {
  IonButton,
  IonCol,
  IonContent,
  IonItem,
  IonPage,
  IonRow,
} from "@ionic/react";
import { useEffect, useState } from "react";

import "./Home.css";
import { ToastContainer } from "react-toastify";
import firebaseConfig from '../../firebaseConfig';
import { toast } from "react-toastify";
import { Bounce } from 'react-toastify';

const Register: React.FC = () => {
  const [isLogined, setIisLogined] = useState(false);

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [user, setUser] = useState({});

  useEffect(() => {
    firebaseConfig.auth().onAuthStateChanged(user => {
      if (user) {
        setIisLogined(true);
        return setUser(user);
      }
    });
  }, [isLogined, user]);

  const registerUser = ({ email, password }: any) => {
    firebaseConfig
      .auth()
      .createUserWithEmailAndPassword(email, password)
      .then((res) => {
        setUser(res);
        return toast.success("Register Success!", { theme: "colored", transition: Bounce });
      })
      .catch((err) => {
        if (err.code === "auth/email-already-in-use") {
          return toast.warning("this email is already in registered!", { theme: "colored", transition: Bounce })
        } else {
          return toast.error("Somthing went wrong!", { theme: "colored", transition: Bounce })
        }
      });
  };
  const handleSubmit = (e: any) => {
    e.preventDefault();
    if (!email || !password) {
      return toast.error("Please fill in all fields!", { theme: "colored" });
    }
    if (password.length < 6) {
      return toast.error("Password must be of 6 or more characters!", { theme: "colored" });
    }
    const data = {
      email,
      password
    };
    registerUser(data);
  };

  const logoutUser = () => {
    firebaseConfig.auth().signOut().then((res) => {
      setIisLogined(false);
      setUser(false);
      return toast.success("Logout seccess", { theme: "colored", transition: Bounce });
    }).catch((err) => {
      return toast.error(err.message, { theme: "colored", transition: Bounce });
    })
  }

  return (
    <IonPage>
      <ToastContainer />
      <IonContent className="ion-text-center">
        <>
          {isLogined ? window.location.replace("/") : (

            <form onSubmit={handleSubmit}>
              <IonRow>
                <IonCol>
                  <h1 className="text-primary text-center py-5 display-4">Regiter</h1>
                </IonCol>
              </IonRow>

              <IonRow>
                <IonCol className="form-group">
                  <IonItem lines="none">
                    <input
                      type="email"
                      placeholder="Email"
                      name="email"
                      className="form-control"
                      value={email}
                      onChange={(e: any) => setEmail(e.target.value)}
                    />
                  </IonItem>
                </IonCol>
              </IonRow>

              <IonRow>
                <IonCol>
                  <IonItem lines="none">
                    <input
                      type="password"
                      placeholder="Password"
                      name="password"
                      className="form-control"
                      value={password}
                      onChange={(e: any) => setPassword(e.target.value)}
                    />
                  </IonItem>
                </IonCol>
              </IonRow>

              <IonRow>
                <IonCol>
                  <IonButton type="submit" expand="block">
                    Regiter
                  </IonButton>
                  <p style={{ fontSize: "medium" }}>
                    Have account? <a href="/">Sign in!</a>
                  </p>
                </IonCol>
              </IonRow>
            </form>

          )}
        </>
      </IonContent>
    </IonPage>
  );
};

export default Register;
